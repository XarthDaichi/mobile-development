package unaeif411.delta.petmatch

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PetMatchApplicationTests {

	@Test
	fun contextLoads() {
	}

}
