package unaeif411.delta.petmatch

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class PetMatchApplication

fun main(args: Array<String>) {
	runApplication<PetMatchApplication>(*args)
}

